import unittest

class Test(unittest.TestCase):
    def test_firstTest(self):
        print("First unit test case.")

if __name__ == "__main__":
    unittest.main()
